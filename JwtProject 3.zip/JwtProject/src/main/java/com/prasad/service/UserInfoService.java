package com.prasad.service;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.prasad.entity.UserInfo;
import com.prasad.repository.UserInfoRepository;

@Service
public class UserInfoService implements UserDetailsService {
	
	@Autowired
    private UserInfoRepository repository; 
  
    @Autowired
    private PasswordEncoder encoder; 
    
    @Autowired
    RestTemplate restTemplate;
  
    @Override
    public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException { 
  
    	//restTemplate.getForEntity("http://", null)
      
    	
        Optional<UserInfo> userDetail = repository.findByName(username); 
  
        // Converting userDetail to UserDetails 
        return userDetail.map(UserInfoDetails::new) 
                .orElseThrow(() -> new UsernameNotFoundException("User not found " + username)); 
    } 
  
    public String addUser(UserInfo userInfo) { 
        userInfo.setPassword(encoder.encode(userInfo.getPassword())); 
        repository.save(userInfo); 
        return "User Added Successfully"; 
    } 

}
