package com.prasad.repository;

import java.util.Optional;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

import com.prasad.entity.UserInfo;

@Repository
public interface UserInfoRepository extends MongoRepository<UserInfo, Integer> {

	Optional<UserInfo> findByName(String name);
}
